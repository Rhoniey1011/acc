import time
import os
import sys
from colorama import init, Fore, Style

init(autoreset=True)

banner = (Style.DIM + "\n© redarchive\n" + Style.RESET_ALL)
name   = "irys-faucet"

def run_once():
    exit_code = os.system(f"{sys.executable} faucet/main.py")
    return exit_code

def shortError(err):
    try:
        s = str(err)
        return s[:200] + ("..." if len(s) > 200 else "")
    except:
        return "Unknown error"
        
def logSpace(lines=1):
    for _ in range(lines):
        print()

def printBanner():
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write(f"\x1b]2;{name}\x07")
    sys.stdout.flush()        
    print(banner)
    print(Style.DIM + f"./{name}" + Style.RESET_ALL)
    logSpace(2)

def timeStamp():
    return time.strftime("%Y/%m/%d %H:%M:%S")

def log(msg, level="info", withTime=True, colorful=True):
    icons = {
        "success": "[✓]",
        "error": "[✗]",
        "warning": "[!]",
        "process": "[→]",
        "info": "[i]",
    }
    colors = {
        "success": Style.BRIGHT + Fore.GREEN,
        "error":   Fore.RED,
        "warning": Fore.YELLOW,
        "process":  Fore.CYAN,
        "info":    Fore.CYAN,
    }
    icon = icons.get(level, "[i]")
    color = colors.get(level, "") if colorful else ""
    ts = f"[{timeStamp()}] " if withTime else ""
    if colorful:
        print(f"{Fore.MAGENTA}{ts}{color}{icon} {msg}{Style.RESET_ALL}")
    else:
        print(f"{ts}{icon} {msg}")

def loop():
    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            logSpace(2)
            log("Process stopped by user", "warning", False)
            break
        except Exception as e:
            log(f"Error during loop: {shortError(e)}", "error")
            logSpace(2)

        log("Waiting 24h before next loop...", "info", False)
        time.sleep(60 * 60 * 24)

if __name__ == "__main__":
    printBanner()
    loop()