import os
import sys
import time
import json
import random
import requests
from urllib.parse import urlparse
from colorama import init, Fore, Style
from pathlib import Path

from seleniumbase import Driver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

init(autoreset=True)

banner     = (Style.DIM + "\n© redarchive\n" + Style.RESET_ALL)
name       = "irys-faucet"
tokens     = ["IRYS"]
faucet_url = "https://irys.xyz/faucet"
api_url    = "https://irys.xyz/api/faucet"

def shortAddress(addr, length=6):
    if not addr: return ""
    if addr.startswith("0x"):
        return f"{addr[:length+2]}...{addr[-4:]}"
    return f"{addr[:length]}...{addr[-4:]}"

def shortProxy(proxy):
    if not proxy:
        return ""
    try:
        url = proxy if "://" in proxy else "http://" + proxy
        p = urlparse(url)
        host = p.hostname or ""
        port = p.port or ""
        return f"{host}:{port}"
    except:
        return proxy

def shortError(err):
    try:
        s = str(err)
        return s[:200] + ("..." if len(s) > 200 else "")
    except:
        return "Unknown error"

def logSpace(lines=1):
    for _ in range(lines):
        print()

def delay_ms(ms):
    time.sleep(ms / 1000)

def randomDelay(minMs=7000, maxMs=10000):
    d = random.randint(minMs, maxMs)
    log(f"Waiting {d//1000}s...", "process")
    time.sleep(d / 1000)

def _requests_get(url, proxy=None, timeout=5):
    proxies = {"http": proxy, "https": proxy} if proxy else None
    return requests.get(url, proxies=proxies, timeout=timeout)

def testProxyConnection(proxy=None):
    apis = [
        "https://api.ipify.org?format=json",
        "https://ifconfig.me/all.json",
        "https://ipapi.co/json/",
        "https://checkip.amazonaws.com",
    ]
    for api in apis:
        try:
            r = _requests_get(api, proxy=proxy, timeout=5)
            if r.status_code == 200:
                ctype = r.headers.get("content-type", "")
                if "application/json" in ctype:
                    data = r.json()
                    ip = data.get("ip") or data.get("ip_addr")
                    if ip: return ip
                else:
                    text = r.text.strip()
                    if text:
                        return text
        except Exception:
            pass
    return None

def getWorkingProxy(proxies, startIndex=0):
    if not proxies:
        ip = testProxyConnection(None)
        return {"proxy": None, "ip": ip}

    n = len(proxies)
    for attempt in range(n):
        idx = (startIndex + attempt) % n
        proxy = proxies[idx]
        ip = testProxyConnection(proxy)
        if ip:
            return {"proxy": proxy, "ip": ip}
        else:
            log(f"Proxy {shortProxy(proxy)} failed, trying next one...", "warning", False)

    log("No working proxy found, falling back to direct connection", "warning", False)
    ip = testProxyConnection(None)
    return {"proxy": None, "ip": ip}

def get_captcha_token(url, max_retries=3):
    for attempt in range(1, max_retries + 1):
        driver = None
        try:
            log("Solving CAPTCHA...", "process")
            driver = Driver(uc=True, headless=True)
            driver.uc_open_with_reconnect(url)
            token_element = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.NAME, "cf-turnstile-response"))
            )
            delay_ms(7000)
            token = token_element.get_attribute("value")

            if token and token != "None":
                log("Successfully solved CAPTCHA", "success")
                return token
            else:
                log("CAPTCHA not solved, retrying...", "warning")

        except Exception as e:
            log(f"Failed to solve CAPTCHA: {shortError(e)}", "error")

        finally:
            if driver:
                try:
                    driver.quit()
                except:
                    pass

        time.sleep(2)

    log(f"Failed to solve CAPTCHA after {max_retries} attempts", "error")
    return None

def req_faucet(turnstile_token: str, address: str, token_name: str, proxy: str | None = None):
    try:
        log(f"Claiming {token_name}...", "process")
        headers = {
            "content-type": "application/json",
            "origin": "https://irys.xyz",
            "referer": f"{faucet_url}/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        }
        data = {
            "captchaToken": turnstile_token,
            "walletAddress": address
        }
        proxies = {"http": proxy, "https": proxy} if proxy else None

        r = requests.post(api_url, headers=headers, data=json.dumps(data), proxies=proxies, timeout=30)
        r.raise_for_status()
        res = r.json()

        if res.get("success"):
            log(f"Successfully claimed {token_name}", "success")
        else:
            log(f"Failed to claim {token_name}: {json.dumps(res, ensure_ascii=False)}", "error")

        return res

    finally:
        randomDelay()

def main():
    base_dir = Path(__file__).resolve().parent.parent
    address_path = base_dir / "address.txt"
    proxy_path   = base_dir / "proxy.txt"    
    
#    address_path = Path("address.txt")
    if not address_path.exists():
        log("No address.txt found", "error", False)
        return
    wallet_data = address_path.read_text().splitlines()
    addresses = [x.strip() for x in wallet_data if x.strip()]

#    proxy_path = Path("proxy.txt")
    proxies = []
    if not proxy_path.exists():
        log("No proxy.txt found, will use direct connection", "warning", False)
    else:
        proxy_data = proxy_path.read_text().splitlines()
        proxies = [x.strip() for x in proxy_data if x.strip()]
        if not proxies:
            log("No proxies found in proxy.txt, will use direct connection", "warning", False)

    if not addresses:
        log("Invalid addresses or no addresses found in address.txt", "error", False)
        return
  
    for idx, address in enumerate(addresses):
        proxy_index = idx % len(proxies) if proxies else 0
        proxy_data = getWorkingProxy(proxies, proxy_index)
        working_proxy = proxy_data["proxy"]
        ip = proxy_data["ip"]

        try:
            log(f"Processing wallet {idx + 1}/{len(addresses)}", 'info', False)
            log(f"Wallet Address: {shortAddress(address)}", 'info', False)
            log(f"Proxy: {shortProxy(working_proxy) if working_proxy else 'No proxy'}", 'info', False)
            log(f"IP: {ip or 'Unknown'}", 'info', False)
            logSpace(1)

            log(f"Starting process for wallet {shortAddress(address)}", 'process')
            randomDelay()
        
            for token_name in tokens:
                token = get_captcha_token(faucet_url)
                if not token:
                    continue

                req_faucet(token, address, token_name, working_proxy)

            log(f"Finished process for wallet {shortAddress(address)}", "success")

            if idx < len(addresses) - 1:
                d = random.randint(7000, 10000)
                log(f"Waiting {d//1000}s before next wallet...", "process")
                logSpace(2)
                delay_ms(d)

        except Exception as e:
            log(f"Error processing wallet {shortAddress(address)}: {shortError(e)}", "error")
            logSpace(2)

    logSpace(2)
    log(f"All wallets finished at {timeStamp()}", "info", False)

def printBanner():
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write(f"\x1b]2;{name}\x07")
    sys.stdout.flush()        
    print(banner)
    print(Style.DIM + f"./{name}" + Style.RESET_ALL)
    logSpace(2)

def timeStamp():
    return time.strftime("%Y/%m/%d %H:%M:%S")

def log(msg, level="info", withTime=True, colorful=True):
    icons = {
        "success": "[✓]",
        "error": "[✗]",
        "warning": "[!]",
        "process": "[→]",
        "info": "[i]",
    }
    colors = {
        "success": Style.BRIGHT + Fore.GREEN,
        "error":   Fore.RED,
        "warning": Fore.YELLOW,
        "process":  Fore.CYAN,
        "info":    Fore.CYAN,
    }
    icon = icons.get(level, "[i]")
    color = colors.get(level, "") if colorful else ""
    ts = f"[{timeStamp()}] " if withTime else ""
    if colorful:
        print(f"{Fore.MAGENTA}{ts}{color}{icon} {msg}{Style.RESET_ALL}")
    else:
        print(f"{ts}{icon} {msg}")
"""
def loop():
    while True:
        try:
            main()
        except KeyboardInterrupt:
            logSpace(2)
            log("Process stopped by user", "warning", False)
            break
        except Exception as e:
            log(f"Error during loop: {shortError(e)}", "error")
            logSpace(2)

        log("Waiting 24h before next loop...", "info", False)
        time.sleep(60 * 60 * 24)
"""
if __name__ == "__main__":
    printBanner()
    main()