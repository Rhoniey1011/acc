import json, sys, time, uuid, signal
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List
import requests
from tenacity import retry, wait_exponential, stop_after_attempt
from rich.console import Console
from termcolor import colored
import pyfiglet

SUPABASE_URL = "https://qevcpuebfogiqtyrxfpv.supabase.co"
ANON_KEY = "sb_publishable_y0JX5vySxUoPYWT9yoROlA_1_uCXOSl"
FUNC_HEARTBEAT = "https://qevcpuebfogiqtyrxfpv.functions.supabase.co/heartbeat"
ACCOUNTS_FILE = "accounts.json"
console = Console()
BOLD = "\033[1m"; RESET = "\033[0m"

def display_banner():
    ascii_art = pyfiglet.figlet_format("Yuurisandesu", font="standard")
    print(colored(f"{BOLD}{ascii_art}{RESET}", "cyan"))
    print(colored(f"{BOLD}Welcome to Yuuri, Browser Cash Auto Mining{RESET}", "magenta"))
    print(colored(f"{BOLD}Ready to hack the world?{RESET}", "green"))
    print(colored(f"{BOLD}Current time: {datetime.now().strftime('%d-%m-%Y %H:%M:%S')}{RESET}", "yellow"))
    print()

def set_window_title():
    sys.stdout.write('\x1b]2;Browser Cash Auto Mining by : 佐賀県産 （𝒀𝑼𝑼𝑹𝑰）\x1b\\')

_ID_MONTH = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agt","Sep","Okt","Nov","Des"]

def _to_local_dt(ts):
    try:
        if isinstance(ts, (int,float)):
            if ts > 1e12: ts = ts/1000.0
            return datetime.fromtimestamp(ts, tz=timezone.utc).astimezone()
        if isinstance(ts, str):
            from datetime import datetime as _dt
            return _dt.fromisoformat(ts).astimezone()
    except Exception:
        pass
    return datetime.now().astimezone()

def _human_clock(dt): return f"{dt.strftime('%H')}:{dt.strftime('%M')} WIB"
def _human_date(dt):
    d = int(dt.strftime("%d")); m = _ID_MONTH[int(dt.strftime("%m"))-1]; y = dt.strftime("%Y")
    return f"{d} {m} {y}"
def fmt_human_ts(ts):
    dt = _to_local_dt(ts)
    return f"{_human_date(dt)} {_human_clock(dt)}"
def fmt_sleep_human(s):
    s = int(s)
    if s < 60: return f"{s}s"
    m = s // 60; r = s % 60
    return f"{m}m" if r == 0 else f"{m}m {r}s"

def load_accounts() -> List[Dict[str, Any]]:
    with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict): accounts = [data]
    elif isinstance(data, list): accounts = data
    else: raise ValueError("accounts.json harus object atau array.")
    for acc in accounts:
        if not acc.get("label"): acc["label"] = "browsercash"
        if not (acc.get("email") and acc.get("password")):
            raise ValueError(f"Akun '{acc.get('label','?')}' butuh email+password")
        if not acc.get("install_id"):
            seed = "browsercash:" + acc["label"] + ":" + acc["email"].lower()
            acc["install_id"] = str(uuid.uuid5(uuid.NAMESPACE_URL, seed))
    return accounts

def headers(access_token: Optional[str] = None, is_json: bool = True) -> Dict[str, str]:
    h = {"apikey": ANON_KEY}
    if access_token: h["Authorization"] = f"Bearer {access_token}"
    if is_json: h["Content-Type"] = "application/json"
    return h

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=6))
def refresh_token_call(refresh_tok: str) -> Dict[str, Any]:
    url = f"{SUPABASE_URL}/auth/v1/token?grant_type=refresh_token"
    r = requests.post(url, headers=headers(is_json=True), json={"refresh_token": refresh_tok}, timeout=30)
    if r.status_code >= 400: raise requests.HTTPError(f"refresh_token failed {r.status_code}: {r.text[:500]}", response=r)
    return r.json()

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=6))
def password_login(email: str, password: str) -> Dict[str, Any]:
    url = f"{SUPABASE_URL}/auth/v1/token?grant_type=password"
    body = {"email": email, "password": password, "gotrue_meta_security": {}}
    h = headers(is_json=True); h["Authorization"] = f"Bearer {ANON_KEY}"
    r = requests.post(url, headers=h, json=body, timeout=30)
    if r.status_code >= 400: raise requests.HTTPError(f"password login failed {r.status_code}: {r.text[:500]}", response=r)
    return r.json()

def ensure_access_token(state: Dict[str, Any], acc: Dict[str, Any]) -> str:
    now = int(time.time()); at = state.get("access_token"); exp = state.get("expires_at")
    if at and exp and int(exp) - now > 60: return at
    rt = state.get("refresh_token_runtime")
    if rt:
        try:
            sess = refresh_token_call(rt)
            state["access_token"] = sess["access_token"]
            if sess.get("refresh_token"): state["refresh_token_runtime"] = sess["refresh_token"]
            if sess.get("expires_in"): state["expires_at"] = now + int(sess["expires_in"])
            return state["access_token"]
        except requests.HTTPError:
            pass
    sess = password_login(acc["email"], acc["password"])
    state["access_token"] = sess["access_token"]
    if sess.get("refresh_token"): state["refresh_token_runtime"] = sess["refresh_token"]
    if sess.get("expires_in"): state["expires_at"] = now + int(sess["expires_in"])
    return state["access_token"]

def get_user_id(access_token: str) -> str:
    u = requests.get(f"{SUPABASE_URL}/auth/v1/user", headers=headers(access_token), timeout=30)
    if u.status_code == 401: raise requests.HTTPError("Unauthorized", response=u)
    u.raise_for_status(); return (u.json() or {}).get("id","")

def rpc(access_token: str, fn: str, payload: Dict[str, Any]) -> Any:
    url = f"{SUPABASE_URL}/rest/v1/rpc/{fn}"
    r = requests.post(url, headers=headers(access_token), json=payload, timeout=30)
    if r.status_code == 401: raise requests.HTTPError("Unauthorized", response=r)
    r.raise_for_status(); return r.json()

def heartbeat(access_token: str, install_id: str) -> Dict[str, Any]:
    r = requests.post(FUNC_HEARTBEAT, headers=headers(access_token), json={"installId": install_id}, timeout=30)
    if r.status_code == 401: raise requests.HTTPError("Unauthorized", response=r)
    r.raise_for_status(); return r.json()

def parse_next_sleep(hb: Dict[str, Any], fallback: int = 60, cap: int = 600) -> int:
    now = time.time()
    if isinstance(hb.get("retryAfter"), (int, float)): return max(10, int(hb["retryAfter"]))
    nxt = hb.get("nextSyncTime")
    if nxt is None: return fallback
    try:
        if isinstance(nxt, (int,float)):
            if nxt > 1e12: nxt = nxt/1000.0
            delta = int(nxt - now)
        elif isinstance(nxt, str):
            delta = fallback
        else:
            delta = fallback
        delta = delta + 1
        return max(10, min(cap, delta))
    except Exception:
        return fallback

def log(text: str, level: str = "info"):
    color = {"info":"bold yellow", "ok":"bold green", "err":"bold red"}.get(level, "bold")
    console.print(text, style=color)

def countdown_sleep(label: str, total_seconds: int, stop_flag: dict) -> None:
    import sys as _sys, time as _time
    for remaining in range(int(total_seconds), 0, -1):
        if stop_flag.get("flag"): break
        text = f"[{label}] sleep {fmt_sleep_human(remaining)}"
        _sys.stdout.write("\r\033[33;1m" + text + "   \033[0m"); _sys.stdout.flush(); _time.sleep(1)
    _sys.stdout.write("\n"); _sys.stdout.flush()

def main():
    set_window_title(); display_banner()
    stop = {"flag": False}
    def handle_sigint(signum, frame): stop["flag"] = True; log("Shutting down...", "info")
    signal.signal(signal.SIGINT, handle_sigint)
    try:
        accounts = load_accounts()
    except Exception as e:
        log(f"Gagal baca accounts.json: {e}", "err"); sys.exit(1)
    STATES: Dict[str, Dict[str, Any]] = {}
    for acc in accounts:
        STATES[acc["install_id"]] = {"access_token": None,"expires_at": None,"refresh_token_runtime": None,"user_id": None,"printed_user_id": False,"last_points": None}
    while not stop["flag"]:
        sleep_candidates = []
        for idx, acc in enumerate(accounts):
            label = acc["label"]; st = STATES[acc["install_id"]]
            try:
                access = ensure_access_token(st, acc)
                if st["user_id"] is None:
                    try:
                        st["user_id"] = get_user_id(access)
                    except requests.HTTPError as e:
                        if getattr(e, "response", None) is not None and e.response.status_code == 401:
                            access = ensure_access_token(st, acc); st["user_id"] = get_user_id(access)
                        else:
                            raise
                    if not st["printed_user_id"]:
                        log(f"[{label}] user_id: {st['user_id']}", "ok"); st["printed_user_id"] = True
                try:
                    points = rpc(access, "get_user_points_balance", {"p_user_id": st["user_id"]})
                except requests.HTTPError as e:
                    if getattr(e, "response", None) is not None and e.response.status_code == 401:
                        access = ensure_access_token(st, acc); points = rpc(access, "get_user_points_balance", {"p_user_id": st["user_id"]})
                    else:
                        raise
                try:
                    daily = rpc(access, "get_user_earnings_last_24h", {"p_user_id": st["user_id"]})
                except requests.HTTPError as e:
                    if getattr(e, "response", None) is not None and e.response.status_code == 401:
                        access = ensure_access_token(st, acc); daily = rpc(access, "get_user_earnings_last_24h", {"p_user_id": st["user_id"]})
                    else:
                        raise
                delta = None
                if isinstance(points,(int,float)) and isinstance(st["last_points"],(int,float)):
                    delta = int(points - st["last_points"])
                st["last_points"] = points
                try:
                    hb = heartbeat(access, acc["install_id"])
                except requests.HTTPError as e:
                    if getattr(e, "response", None) is not None and e.response.status_code == 401:
                        access = ensure_access_token(st, acc); hb = heartbeat(access, acc["install_id"])
                    else:
                        raise
                ok = bool(hb.get("success")); lvl = "ok" if ok else "info"
                if isinstance(delta, int):
                    sign = "+" if delta >= 0 else ""
                    log(f"[{label}] points: {points} ({sign}{delta})", lvl)
                else:
                    log(f"[{label}] points: {points}", lvl)
                log(f"[{label}] earnings 24h: {daily}", lvl)
                log(f"[{label}] heartbeat: {'OK' if ok else 'PENDING'}", lvl)
                if hb.get("earnRate") is not None: log(f"[{label}] earn rate: {hb.get('earnRate')}", lvl)
                if hb.get("lastSyncTime") is not None: log(f"[{label}] last sync: {fmt_human_ts(hb.get('lastSyncTime'))}", "info")
                if hb.get("nextSyncTime") is not None: log(f"[{label}] next sync: {fmt_human_ts(hb.get('nextSyncTime'))}", "info")
                sleep_s = parse_next_sleep(hb, fallback=60, cap=600); sleep_candidates.append(sleep_s)
                if idx != len(accounts) - 1: console.print("")
            except requests.HTTPError as e:
                status = getattr(e.response, "status_code", "?")
                try: body = e.response.text[:300]
                except Exception: body = str(e)
                log(f"[{label}] HTTP {status}: {body}", "err"); log(f"[{label}] retry in 10s", "info"); time.sleep(10)
            except Exception as e:
                log(f"[{label}] ERROR: {repr(e)}", "err"); log(f"[{label}] retry in 10s", "info"); time.sleep(10)
        if sleep_candidates:
            last_label = accounts[-1]["label"]; min_sleep = min(sleep_candidates)
            countdown_sleep(last_label, min_sleep, {"flag": False})

if __name__ == "__main__":
    main()
