const fs = require('fs').promises;
const chalk = require('chalk');
const axios = require('axios');
const { ethers } = require('ethers');
const { fetch } = require('undici');
const { HttpsProxyAgent } = require('https-proxy-agent');

const banner   = `${chalk.dim('\n© redarchive\n')}`;
const name     = 'monad';
const rpc      = 'https://testnet-rpc.monad.xyz/';
const chain    = 10143;
const explorer = 'https://testnet.monadexplorer.com/';

const router_address = toChecksum("0xb6091233aAcACbA45225a2B2121BBaC807aF4255");
const wmon_address	 = toChecksum("0x760AfE86e5de5fa0Ee542fc7B7B713e1c5425701");

const tokenList = [
    { address: toChecksum("0xCa9A4F46Faf5628466583486FD5ACE8AC33ce126"), symbol: "OCTO", decimals: 18 },
    { address: toChecksum("0xb38bb873cca844b20A9eE448a87Af3626a6e1EF5"), symbol: "MIST", decimals: 18 },
    { address: toChecksum("0xAbF39775d23c5B6C0782f3e35B51288bdaf946e2"), symbol: "CULT", decimals: 18 },
    { address: toChecksum("0x8589a0dD9eCD77B7D70Ff76147dcE366bF31254E"), symbol: "gigaETH", decimals: 18 },
    { address: toChecksum("0x88b8E2161DEDC77EF4ab7585569D2415a1C1055D"), symbol: "USDT", decimals: 6 }
];

const router_abi = [
    "function getAmountsOut(uint amountIn, address[] memory path) view returns (uint[] memory amounts)",
    "function swapExactTokensForTokens(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline) returns (uint[] memory amounts)",
    "function swapExactETHForTokens(uint amountOutMin, address[] calldata path, address to, uint deadline) payable returns (uint[] memory amounts)",
    "function swapExactTokensForETH(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline) returns (uint[] memory amounts)",
    "function addLiquidity(address tokenA, address tokenB, uint amountADesired, uint amountBDesired, uint amountAMin, uint amountBMin, address to, uint deadline) returns (uint amountA, uint amountB, uint liquidity)",
    "function addLiquidityETH(address token, uint amountTokenDesired, uint amountTokenMin, uint amountETHMin, address to, uint deadline) payable returns (uint amountToken, uint amountETH, uint liquidity)"
];

const erc20_abi = [
    "function balanceOf(address) view returns (uint256)",
    "function approve(address spender, uint256 amount) returns (bool)",
    "function allowance(address owner, address spender) view returns (uint256)",
	"function decimals() view returns (uint8)" 
];

const wmon_abi = [
    "function deposit() payable",
    "function withdraw(uint256 wad)",
    "function approve(address spender,uint256 amount) returns (bool)",
    "function allowance(address owner,address spender) view returns (uint256)",
    "function balanceOf(address account) view returns (uint256)"
];

function toChecksum(address) {
    if (!address.startsWith("0x")) throw new Error("Invalid address");
    const body = address.slice(2);
    if (body === body.toLowerCase()) {
        return ethers.utils.getAddress(address);
    }
    return address;
}

function getRandomTokens(list, count = list.length) {
    return list
        .sort(() => 0.5 - Math.random())
        .slice(0, count);
}

function formatUnits(amount, decimals = 18, symbol = "", prefer = { d18: 6, d8: 6, d6: 6, other: 6 }) {
    if (!amount) return "0";

    const s = ethers.utils.formatUnits(amount, decimals);

    let precision = prefer.other;
    if (decimals === 18) precision = prefer.d18;
    else if (decimals === 8) precision = prefer.d8;
    else if (decimals === 6) precision = prefer.d6;

    const n = Number(s);
    if (!isFinite(n)) return s;

    if (n !== 0 && Math.abs(n) < 0.000001) {
        return n.toExponential(2);
    }

    return n.toFixed(precision).replace(/\.?0+$/, "");
}

function randomSplit(totalPercent, n, minPercent = 5) {
    if (n * minPercent > totalPercent) {
        const base = Math.floor(totalPercent / n);
        const result = Array(n).fill(base);
        let remainder = totalPercent - base * n;

        for (let i = 0; remainder > 0; i = (i + 1) % n, remainder--) {
            result[i]++;
        }

        return result;
    }

    let randoms = Array.from({ length: n }, () => Math.random());
    let sum = randoms.reduce((a, b) => a + b, 0);

    let percents = randoms.map(r => Math.max(minPercent, Math.round(r / sum * totalPercent)));
    let diff = percents.reduce((a, b) => a + b, 0) - totalPercent;

    while (diff !== 0) {
        for (let i = 0; i < n && diff !== 0; i++) {
            if (diff > 0 && percents[i] > minPercent) {
                percents[i]--;
                diff--;
            } else if (diff < 0) {
                percents[i]++;
                diff++;
            }
        }
    }

    return percents;
}

async function enrichToken(provider, token) {
    const contract = new ethers.Contract(token.address, erc20_abi, provider);
    let decimals = token.decimals;
    try {
        decimals = await contract.decimals();
    } catch (err) {
        log(`Failed to get ${token.symbol} decimals, use default ${token.decimals}`, 'warning');
    }
    return { ...token, decimals };
}

function shortAddress(addr, length = 6) {
    if (!addr) return "";
    return `${addr.slice(0,length+2)}...${addr.slice(-4)}`;
}

function shortProxy(proxy) {
    if (!proxy) return "";
    try {
        const url = proxy.includes("://") ? new URL(proxy) : new URL("http://" + proxy);
        return `${url.hostname}:${url.port}`;
    } catch {
        return proxy;
    }
}

function shortError(err) {
    if (!err) return "Unknown error";

    if (err.reason) return err.reason;
    if (err.message) return err.message;
    if (err.error?.message) return err.error.message;

    if (err.body) {
        try {
            const body = JSON.parse(err.body);
            if (body.error?.message) return body.error.message;
            if (body.result && typeof body.result === "string") return body.result;
        } catch {}
    }

    try {
        return String(err).slice(0, 200) + (String(err).length > 200 ? "..." : "");
    } catch {
        return "Unknown error";
    }
}

function logSpace(lines = 1) {
    for (let i = 0; i < lines; i++) console.log();
}

function delay(ms) { 
    return new Promise(resolve => setTimeout(resolve, ms)); 
}

async function randomDelay(minMs = 7000, maxMs = 10000) {
    const delayMs = Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
    log(`Waiting ${Math.floor(delayMs/1000)}s...`, 'process');
    await delay(delayMs);
}

async function testProxyConnection(proxy) {
    const apis = [
        'https://api.ipify.org?format=json',
        'https://ifconfig.me/all.json',
        'https://ipapi.co/json/',
        'https://checkip.amazonaws.com'
    ];

    const options = { timeout: 5000 };
    if (proxy) {
        options.httpsAgent = new HttpsProxyAgent(proxy);
    }

    for (const api of apis) {
        try {
            const response = await axios.get(api, options);
            if (response.data) {
                if (response.data.ip) return response.data.ip;
                if (response.data.ip_addr) return response.data.ip_addr;
                if (typeof response.data === "string") return response.data.trim();
            }
        } catch (err) {
        }
    }

    return null;
}

async function getWorkingProxy(proxies, startIndex = 0) {
    if (!proxies || proxies.length === 0) {
        const ip = await testProxyConnection(null);
        return { proxy: null, ip };
    }

    for (let attempt = 0; attempt < proxies.length; attempt++) {
        const index = (startIndex + attempt) % proxies.length;
        const proxy = proxies[index];
        const ip = await testProxyConnection(proxy);
        if (ip) {
            return { proxy, ip };
        } else {
            log(`Proxy ${shortProxy(proxy)} failed, trying next one...`, 'warning', false);
        }
    }

    log(`No working proxy found, falling back to direct connection`, 'warning', false);
    const ip = await testProxyConnection(null);
    return { proxy: null, ip };
}

async function createProvider(proxy) {
    if (!proxy) {
        return new ethers.providers.JsonRpcProvider(rpc, chain);
    }

    const agent = new HttpsProxyAgent(proxy);
    return new ethers.providers.JsonRpcProvider(
        { url: rpc, fetch: (url, opts) => fetch(url, { ...opts, dispatcher: agent }) },
        chain
    );
}

async function getGasPrice(provider) {
    const feeData = await provider.getFeeData();

    if (feeData.gasPrice) {
        return { gasPrice: feeData.gasPrice };
    }

    const block = await provider.getBlock("latest");
    if (block && block.baseFeePerGas) {
        const priorityFee = ethers.utils.parseUnits("1", "gwei");
        return {
            maxPriorityFeePerGas: priorityFee,
            maxFeePerGas: block.baseFeePerGas.mul(2).add(priorityFee),
        };
    }

    return { gasPrice: ethers.utils.parseUnits("1", "gwei") };
}

async function addGasLimit(wallet, txData) {
    const estimatedGas = await wallet.estimateGas(txData);
    return { ...txData, gasLimit: estimatedGas.mul(120).div(100) };
}

async function getTxType(provider) {
    const feeData = await provider.getFeeData();
    return (feeData.maxFeePerGas && feeData.maxPriorityFeePerGas) ? 2 : 0;
}

async function sendTx(wallet, txData) {
    const txType = await getTxType(wallet.provider);
    const finalTx = await addGasLimit(wallet, { 
        ...txData, 
        ...(txType === 0 ? { type: 0 } : {}) 
    });
    const tx = await wallet.sendTransaction(finalTx);
    return await tx.wait();
}

async function ensureAllowance(tokenContract, owner, spender, amount, wallet, tokenSymbol) {
    try {
        const allowance = await tokenContract.allowance(owner, spender);
        if (allowance.lt(amount)) {
            log(`Approving ${tokenSymbol}...`, 'process');
            const gasOptions = await getGasPrice(wallet.provider);
			const txData = {
				to: tokenContract.address,
				data: tokenContract.interface.encodeFunctionData('approve', [spender, ethers.constants.MaxUint256]),
				...gasOptions,
			};
			
			const receipt = await sendTx(wallet, txData);
        }
    } catch (err) {
        log(`Failed to approve ${tokenSymbol}: ${shortError(err)}`, 'error');
    }
}

async function getBestRoute(router, amountIn, tokenIn, tokenOut, tokens) {
    const candidateRoutes = [];

    candidateRoutes.push([tokenIn, tokenOut]);

    for (const mid of tokens) {
        if ([tokenIn, tokenOut].includes(mid.address.toLowerCase())) continue;
        candidateRoutes.push([tokenIn, mid.address, tokenOut]);
    }

    for (const mid1 of tokens) {
        if ([tokenIn, tokenOut].includes(mid1.address.toLowerCase())) continue;
        for (const mid2 of tokens) {
            if ([tokenIn, tokenOut, mid1.address].includes(mid2.address.toLowerCase())) continue;
            candidateRoutes.push([tokenIn, mid1.address, mid2.address, tokenOut]);
        }
    }

    let bestRoute = null;
    let bestAmount = ethers.BigNumber.from(0);

    for (const route of candidateRoutes) {
        try {
            const amounts = await router.getAmountsOut(amountIn, route);
            const out = amounts[amounts.length - 1];
            if (out.gt(bestAmount)) {
                bestAmount = out;
                bestRoute = route;
            }
        } catch (err) {
            continue;
        }
    }

    return bestRoute;
}

async function wrap(wallet, wmonContract, amount) {
    try {
        log(`Wrapping ${formatUnits(amount)} MON to WMON...`, 'process');
        const gasOptions = await getGasPrice(wallet.provider);
        const txData = {
            to: wmon_address,
            data: wmonContract.interface.encodeFunctionData("deposit"),
            value: amount,
            ...gasOptions
        };
        const receipt = await sendTx(wallet, txData);
		
        log(`Successfully wrapped MON to WMON`, 'success');
        log(`${explorer}tx/${receipt.transactionHash}`, 'process');
    } catch (err) {
        log(`Failed to wrap MON to WMON: ${shortError(err)}`, 'error');
    } finally {
        await randomDelay();
    }
}

async function swap(wallet, wmonContract, router, tokens, monToSwap) {
    const tokenBalances = [];

    const selectedTokens = getRandomTokens(tokens);
    const randomPercents = randomSplit(100, selectedTokens.length);
    
    for (let idx = 0; idx < selectedTokens.length; idx++) {
        const token = selectedTokens[idx];
        if (token.address === wmon_address) continue;

        const amountToSwap = monToSwap.mul(randomPercents[idx]).div(100);
        if (amountToSwap.isZero()) {
            log(`Skip swap WMON, balance too low`, 'warning');
            continue;
        }

        try {
            log(`Swapping ${formatUnits(amountToSwap)} WMON to ${token.symbol} via OctoDex...`, 'process');		

            const route = await getBestRoute(router, amountToSwap, wmon_address, token.address, tokens);
            if (!route) { 
                log(`No route found for WMON to ${token.symbol}`, 'warning'); 
                continue; 
            }

            await ensureAllowance(wmonContract, wallet.address, router_address, amountToSwap, wallet, "WMON");

            const gasOptions = await getGasPrice(wallet.provider);

            const amountsOut = await router.getAmountsOut(amountToSwap, route);
            const minOut = amountsOut[amountsOut.length - 1].mul(99).div(100)
            const txData = await router.populateTransaction.swapExactTokensForTokens(
                amountToSwap,
                minOut,
                route,
                wallet.address,
                Math.floor(Date.now() / 1000) + 3600,
                gasOptions
            );

            const receipt = await sendTx(wallet, txData);

            log(`Successfully swapped WMON to ${token.symbol}`, 'success');
            log(`${explorer}tx/${receipt.transactionHash}`, 'process');
            const tokenContract = new ethers.Contract(token.address, erc20_abi, wallet);
            const tokenBalance = await tokenContract.balanceOf(wallet.address);
            tokenBalances.push({ token, balance: tokenBalance });
        } catch (err) {
            log(`Failed to swap WMON to ${token.symbol}: ${shortError(err)}`, 'error');
        } finally {
            await randomDelay();
        }
    }

    return tokenBalances;
}

async function swapback(wallet, router, tokenBalances, percent) {
    for (const { token, balance } of tokenBalances) {
        try {
            const tokenContract = new ethers.Contract(token.address, erc20_abi, wallet);

            const tokenToSwap = balance.mul(percent).div(100);
            if (tokenToSwap.isZero()) {
                log(`Skip swap ${token.symbol}, balance too low`, 'warning');
                continue;
            }

            log(`Swapping ${formatUnits(tokenToSwap, token.decimals)} ${token.symbol} to WMON via OctoDex...`, 'process');

            const routeBack = await getBestRoute(router, tokenToSwap, token.address, wmon_address, tokenList);
            if (!routeBack) {
                log(`No route found for ${token.symbol} to WMON`, 'warning');
                continue;
            }
            await ensureAllowance(tokenContract, wallet.address, router_address, tokenToSwap, wallet, token.symbol);

            const gasOptions = await getGasPrice(wallet.provider);
            const amountsOut = await router.getAmountsOut(tokenToSwap, routeBack);
            const minOut = amountsOut[amountsOut.length - 1].mul(99).div(100);
            const txData = await router.populateTransaction.swapExactTokensForTokens(
                tokenToSwap,
                minOut,
                routeBack,
                wallet.address,
                Math.floor(Date.now() / 1000) + 3600,
                gasOptions
            );
            const receipt = await sendTx(wallet, txData);

            log(`Successfully swapped ${token.symbol} to WMON`, 'success');
            log(`${explorer}tx/${receipt.transactionHash}`, 'process');
        } catch (err) {
            log(`Failed to swap ${token.symbol} to WMON: ${shortError(err)}`, 'error');
        } finally {
            await randomDelay();
        }
    }
}

async function unwrap(wallet, wmonContract, amount) {
    try {
        log(`Unwrapping ${formatUnits(amount)} WMON to MON...`, 'process');
        const gasOptions = await getGasPrice(wallet.provider);
        const txData = {
            to: wmon_address,
            data: wmonContract.interface.encodeFunctionData("withdraw", [amount]),
            ...gasOptions
        };
        const receipt = await sendTx(wallet, txData);
		
        log(`Successfully unwrapped WMON to MON`, 'success');
        log(`${explorer}tx/${receipt.transactionHash}`, 'process');
    } catch (err) {
        log(`Failed to unwrap WMON to MON: ${shortError(err)}`, 'error');
    } finally {
        await randomDelay();
    }
}

async function addLiquidity(wallet, router, token, amount) {
    try {
        const tokenContract = new ethers.Contract(token.address, erc20_abi, wallet);

        const balanceETH = await wallet.getBalance();
        const balanceToken = await tokenContract.balanceOf(wallet.address);

        const amountETHDesired = ethers.utils.parseEther(String(amount));
        if (balanceETH.lt(amountETHDesired) || balanceToken.isZero()) {
            log(`Skip add liquidity ${token.symbol} or MON, balance too low`, 'warning');
            return;
        }

        const amountTokenDesired = balanceToken;
		log(
            `Adding liquidity ${formatUnits(amountETHDesired)} MON and ${formatUnits(amountTokenDesired, token.decimals)} ${token.symbol} via OctoDex...`,
            'process'
        );	        
		
        await ensureAllowance(tokenContract, wallet.address, router_address, amountTokenDesired, wallet, token.symbol);

        const amountTokenMin = 0;
        const amountETHMin = 0;
        const deadline = Math.floor(Date.now() / 1000) + 600;
        const gasOptions = await getGasPrice(wallet.provider);

        const txData = await router.populateTransaction.addLiquidityETH(
            token.address,
            amountTokenDesired,
            amountTokenMin,
            amountETHMin,
            wallet.address,
            deadline,
            { ...gasOptions, value: amountETHDesired }
        );
        const receipt = await sendTx(wallet, txData);

        log(`Successfully added liquidity MON and ${token.symbol}`, 'success');
        log(`${explorer}tx/${receipt.transactionHash}`, 'process');
    } catch (err) {
        log(`Failed to add liquidity ${token.symbol}/MON: ${shortError(err)}`, 'error');
    } finally {
        await randomDelay();
    }
}

async function main() {
	const wrapPercent     = 50;
	const swapbackPercent = 90;
	const unwrapPercent   = 100;
	const addLiqAmount    = "0.0001";

    let walletData = '';

    try {
        walletData = await fs.readFile('privatekey.txt', 'utf8');
    } catch (err) {
        log("No privatekey.txt found", 'error', false);
        return;
    }

    let proxies = [];
	
    try {
        const proxyData = await fs.readFile('proxy.txt', 'utf8');
        proxies = proxyData.split('\n').map(x => x.trim()).filter(Boolean);
        if (proxies.length === 0) {
            log("No proxies found in proxy.txt, will use direct connection", 'warning', false);
        }
    } catch (err) {
        log("No proxy.txt found, using direct connection", 'warning', false);
    }

    const privateKeys = walletData.split('\n').map(x => x.trim()).filter(Boolean);

    if (!privateKeys.length) {
        log("Invalid private keys or no private keys found in privatekey.txt", 'error', false);
        return;
    }

    for (let idx = 0; idx < privateKeys.length; idx++) {
        const privateKey = privateKeys[idx];
        const proxyIndex = proxies.length ? idx % proxies.length : 0;
		let address = '';
			
		try {
			const { proxy: workingProxy, ip } = await getWorkingProxy(proxies, proxyIndex);
			const provider = await createProvider(workingProxy);			
			const wallet = new ethers.Wallet(privateKey, provider);
			address = wallet.address;
			
			log(`Processing wallet ${idx + 1}/${privateKeys.length}`, 'info', false);
			log(`Wallet Address: ${shortAddress(address)}`, 'info', false);
			log(`Proxy: ${workingProxy ? shortProxy(workingProxy) : "No proxy (Direct connection)"}`, 'info', false);
			log(`IP: ${ip || "Unknown"}`, 'info', false);
			logSpace(1);
			
			log(`Starting process for wallet ${shortAddress(address)}`, 'process');
			await randomDelay();

			const wmonContract = new ethers.Contract(wmon_address, wmon_abi, wallet);
			const router = new ethers.Contract(router_address, router_abi, wallet);
			
			const balance = await provider.getBalance(wallet.address);
			const monToSwap = balance.mul(wrapPercent).div(100);
			if (monToSwap.isZero()) { 
				log(`MON balance too low`, 'warning'); 
				continue; 
			}

			await wrap(wallet, wmonContract, monToSwap);

			const enrichedtokenList = await Promise.all(tokenList.map(t => enrichToken(provider, t)));
			const tokens = await swap(wallet, wmonContract, router, enrichedtokenList, monToSwap);

			await swapback(wallet, router, tokens, swapbackPercent);
			
			const wmonBalance = await wmonContract.balanceOf(wallet.address);
			if (wmonBalance.gt(0)) {
				const unwrapAmount = wmonBalance.mul(unwrapPercent).div(100);
				await unwrap(wallet, wmonContract, unwrapAmount);
			}

			await addLiquidity(wallet, router, tokenList[0], addLiqAmount);
			
			log(`Finished process for wallet ${shortAddress(address)}`, 'success');

            if (idx < privateKeys.length - 1) {
                const delayMs = Math.floor(Math.random() * (10000 - 7000 + 1)) + 7000;
                log(`Waiting ${Math.floor(delayMs / 1000)}s before next wallet...`, 'process');
                logSpace(2);
                await delay(delayMs);
            }

		} catch (err) {
			log(`Error processing wallet ${shortAddress(address)}: ${shortError(err)}`, 'error');
			logSpace(2);
		}
	}

	logSpace(2);
	log(`All wallets finished at ${timeStamp()}`, 'info', false);
}

function printBanner(name) {
    process.stdout.write('\x1Bc');
    process.stdout.write(`\x1b]2;${name}\x1b\x5c`);
    console.log(banner); 
    console.log(chalk.dim(`./${name}`));
    logSpace(2);
}

function timeStamp() {
    const now = new Date();
    return `${now.getFullYear()}/${String(now.getMonth()+1).padStart(2,'0')}/${String(now.getDate()).padStart(2,'0')} ` +
           `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')}`;
}

function log(msg, type = 'info', withTime = true, colored = true) {
    const icons = {
        success: "[✓]",
        error: "[✗]",
        warning: "[!]",
        process: "[→]",
        info: "[i]"
    };

    const colors = {
        success: chalk.greenBright,
        error: chalk.red,
        warning: chalk.yellow,
        process: chalk.cyan,
        info: chalk.cyan
    };

    const icon = icons[type] || icons.info;
    const colorFn = (colored ? colors[type] : (txt) => txt) || ((txt) => txt);
    const tsColorFn = colored ? chalk.magenta : chalk.white;

    const timeStr = withTime ? `[${timeStamp()}]` : "";

    const formatted = 
        (withTime ? tsColorFn(timeStr) + " " : "") +
        colorFn(`${icon} ${msg}`);

    console.log(formatted);
}
/*
async function loop() {
    while (true) {
        try {
            await main();
        } catch (err) {
            log(`Error during loop: ${shortError(err)}`, 'error');
			logSpace(2);
        }

        log("Waiting 24h before next loop...", "info", false);
        await delay(24 * 60 * 60 * 1000);

    }
}
*/
process.on('SIGINT', () => {
    logSpace(2);
	log("Process stopped by user", "warning", false);
    process.exit();
});

printBanner(name);
main();