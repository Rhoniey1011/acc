const { spawn } = require('child_process');
const path = require('path');
const readline = require('readline');
const chalk = require('chalk');

const banner = `${chalk.dim('\n© redarchive\n')}`;
const name   = 'monad';

const scripts = [
    path.join(__dirname, 'scripts', 'deploy.js'),
    path.join(__dirname, 'scripts', 'stake.js'),
    path.join(__dirname, 'scripts', 'aprio.js'),
    path.join(__dirname, 'scripts', 'lumiterra.js'),
    path.join(__dirname, 'scripts', 'wonad.js'),
    path.join(__dirname, 'scripts', 'bean.js'),
    path.join(__dirname, 'scripts', 'madness.js'),
    path.join(__dirname, 'scripts', 'taya.js'),
    path.join(__dirname, 'scripts', 'octo.js'),
    path.join(__dirname, 'scripts', 'curvance.js'),
];

function printBanner(name) {
    process.stdout.write('\x1Bc');
    process.stdout.write(`\x1b]2;${name}\x1b\x5c`);
    console.log(banner); 
    console.log(chalk.dim(`./${name}`));
    logSpace(2);
}

function timeStamp() {
    const now = new Date();
    return `${now.getFullYear()}/${String(now.getMonth()+1).padStart(2,'0')}/${String(now.getDate()).padStart(2,'0')} ` +
           `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')}`;
}

function log(msg, type = 'info', withTime = true, colored = true) {
    const icons = {
        success: "[✓]",
        error: "[✗]",
        warning: "[!]",
        process: "[→]",
        info: "[i]"
    };

    const colors = {
        success: chalk.greenBright,
        error: chalk.red,
        warning: chalk.yellow,
        process: chalk.cyan,
        info: chalk.cyan
    };

    const icon = icons[type] || icons.info;
    const colorFn = (colored ? colors[type] : (txt) => txt) || ((txt) => txt);
    const tsColorFn = colored ? chalk.magenta : chalk.white;

    const timeStr = withTime ? `[${timeStamp()}]` : "";

    const formatted = 
        (withTime ? tsColorFn(timeStr) + " " : "") +
        colorFn(`${icon} ${msg}`);

    console.log(formatted);
}

function logSpace(lines = 1) {
    for (let i = 0; i < lines; i++) console.log();
}

function runScript(scriptPath) {
    return new Promise((resolve, reject) => {
        const configPreload = path.join(__dirname, 'config.js');

        const child = spawn('node', ['-r', configPreload, scriptPath], {
            stdio: 'inherit'
        });

        child.on('close', (code) => {
            if (code !== 0) {
                log(`Error in ${path.basename(scriptPath, '.js')} (exit code ${code})`, 'error');
                reject(new Error(`Exit code ${code}`));
                return;
            }
            resolve();
        });
    });
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.on('SIGINT', () => {
    logSpace(2);
    log("Process stopped by user", "warning", false);
    rl.close();
    process.exit(0);
});

printBanner(name);

console.log(chalk.cyan(`0. Run all`));
scripts.forEach((script, i) => {
    console.log(chalk.cyan(`${i + 1}. ${path.basename(script, '.js')}`));
});
logSpace(2);

async function loop(scriptPaths) {
    while (true) {
        for (const script of scriptPaths) {
            try {
                await runScript(script);
            } catch (err) {
                log(`Skip ${path.basename(script, '.js')} due to error.`, 'error', false);
            }
        }

        log("Waiting 24h before next loop...", "info", false);
        await new Promise(resolve => setTimeout(resolve, 24 * 60 * 60 * 1000));
    }
}

rl.question(chalk.cyan("Select the script you want to run: "), async (answer) => {
    const choice = parseInt(answer, 10);

    if (choice === 0) {
        await loop(scripts);
    } else if (choice > 0 && choice <= scripts.length) {
        await loop([scripts[choice - 1]]);
    } else {
        log(`Invalid selection!`, 'warning', false);
        rl.close();
    }
});
