const fs = require('fs').promises;
const path = require('path');

(async function load() {
    try {
        const base = __dirname;
        const proxyPath = path.join(base, 'proxy.txt');
        const keyPath   = path.join(base, 'privatekey.txt');

        const proxyRaw = await fs.readFile(proxyPath, 'utf8').catch(() => '');
        const keyRaw   = await fs.readFile(keyPath, 'utf8').catch(() => '');

        const proxies = proxyRaw
            .split(/\r?\n/)
            .map(l => l.trim())
            .filter(Boolean);

        const keys = keyRaw
            .split(/\r?\n/)
            .map(l => l.trim())
            .filter(Boolean);

        global.CONFIG = {
            proxies,
            keys,
            paths: {
                proxy: proxyPath,
                privatekey: keyPath,
                root: base
            },
            loadedAt: new Date().toISOString()
        };

    } catch (err) {
        console.error('Failed to load config:', err && err.message ? err.message : err);
    }
})();

module.exports = {};
